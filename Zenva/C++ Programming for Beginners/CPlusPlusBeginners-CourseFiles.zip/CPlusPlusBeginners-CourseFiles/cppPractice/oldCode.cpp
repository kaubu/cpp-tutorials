// Lesson 4
// #include <iostream>
// // This is a comment
// using namespace std;
// int main() 
// {
//     // cout << "Hi my name is Nimish and I am " << 26 << " years old";
//     // string input;
//     // cin >> input;
//     // cout << input;
//     string name;
//     string age;
//     cin >> name;
//     cin >> age;
//     cout << "Hi my name is " << name << " and I am " << age << " years old";
// }

// Lesson 5
// #include <iostream>
// using namespace std;
// int main() 
// {
//     bool isGameOver;
//     isGameOver = false;
//     isGameOver = true;
//     bool isNotGameOver = isGameOver;
//     isGameOver = false;
//     isGameOver = 5 > 2;
//     int currentHealth = 100;
//     currentHealth = 50 - 2;
//     float percentHealth = 5;
//     double pi = 3.14159;
// }

// Lesson 6
// #include <iostream>
// using namespace std;
// int main() 
// {
//     char g = 'g';
//     char period = '.';
//     char one = '1';
//     string playerName = "Nimish";
//     string empty = "";
//     cout << playerName.length();
//     playerName.append("fafadsfadsf");
//     cout << playerName;
// }

// Lesson 7
// #include <iostream>
// using namespace std;
// int main() 
// {
//     int someInt = 1;
//     int * ptr = &someInt;
//     someInt = 5;
//     cout << * ptr;
//     // int someOtherInt = someInt;
//     // someInt = 5;
//     // cout << someOtherInt;
// }

// Lesson 8
// #include <iostream>
// using namespace std;
// int main() 
// {
//     int maxHealth = 100;
//     int currentHealth = maxHealth;
//     bool isGameOver = false;
//     isGameOver = !isGameOver;
//     currentHealth = currentHealth - 10;
//     // cout << currentHealth % 80;
//     currentHealth++;
//     currentHealth += 10;
//     // cout << currentHealth;
//     string playerName = "Nimish";
//     string welcome = "Welcome ";
//     cout << welcome + playerName;
// }

// Lesson 9
// #include <iostream>
// using namespace std;
// int main() 
// {
//     int maxHealth = 100;
//     int currentHealth = 50;
//     bool isTrue = currentHealth != maxHealth;
//     // bool otherIsTrue = isTrue == true;
//     bool otherIsTrue = isTrue;
//     string firstName = "Nimish";
//     string lastName = "Narang";
//     isTrue = firstName != lastName;
//     isTrue = currentHealth != maxHealth && firstName == lastName; // false
//     isTrue = currentHealth != maxHealth || firstName == lastName; // true
// }

// Lesson 10
// #include <iostream>
// using namespace std;
// int main() 
// {
//     // string inventory[3];
//     // inventory[0] = "Sword";
//     // inventory[1] = "Shield";
//     // inventory[2] = "Boots";
//     string inventory[] = {"Sword", "Shield", "Boots"};
// }

// Lesson 11
// #include <iostream>
// #include <vector>
// using namespace std;
// int main() 
// {
//     vector<string> inventory;
//     inventory.push_back("Sword");
//     inventory.push_back("Shield");
//     inventory.pop_back();
//     // inventory.insert(1, "Boots");
//     inventory.size();
//     inventory.front();
//     inventory.back();
//     inventory.clear();
// }

// Lesson 12
// #include <iostream>
// using namespace std;
// int main() 
// {
//     int health = 0;
//     if (health <= 0) {
//         cout << "You died, game over!";
//     } else if (health <= 10) {
//         cout << "You're low health, be careful!";
//     } else {
//         cout << "You're still alive, keep going!";
//     }
// }

// Lesson 13
// #include <iostream>
// using namespace std;
// int main() 
// {
//     // bool isGameRunning = true;
//     int xPos = 0;
//     int endPos = 10;
//     while (true) {
//         xPos += 1;
//         cout << xPos << "\n";
//         if (xPos >= endPos) {
//             // isGameRunning = false;
//             break;
//         }
//     }
//     cout << "Game over!";
// }

// Lesson 14
// #include <iostream>
// using namespace std;
// int main() 
// {
//     int n = 3;
//     string inventory[n];
//     inventory[0] = "Sword";
//     inventory[1] = "Shield";
//     inventory[2] = "Bow";
//     for (int i = 0; i < n; i++) {
//         cout << inventory[i] << "\n";
//     }
// }

// Lesson 15
// #include <iostream>
// using namespace std;
// int takeDamage(int attack, int defence) {
//     int damage = attack - defence;
//     if (damage < 0) {
//         damage = 0;
//     }
//     return damage;
// }
// int main() 
// {
//     int damage = takeDamage(10, 5);
//     cout << damage;
// }

// Lessons 16 and 17
// #include <iostream>
// using namespace std;
// class GameCharacter
// {
// public:
//     int maxHealth, currentHealth, attack, defence;
//     GameCharacter(int, int, int);
//     void takeDamage(int);
// };
// GameCharacter::GameCharacter(int h, int a, int d) {
//     maxHealth = h;
//     currentHealth = h;
//     attack = a;
//     defence = d;
// }
// void GameCharacter::takeDamage(int a) {
//     int damage = a - defence;
//     if (damage < 0) {
//         damage = 0;
//     }
//     currentHealth -= damage;
// }
// int main() 
// {
//     GameCharacter gc = GameCharacter(100, 10, 10);
//     cout << "Current health: " << gc.currentHealth;
//     gc.takeDamage(20);
//     cout << "Current health: " << gc.currentHealth;
// }

// Lesson 18
// class Player: public GameCharacter {
// public:
//     vector<string> inventory;
//     string name;
//     Player(string, int, int, int);
//     void addItem(string);
// };
// Player::Player(string n, int h, int a, int d): 
// GameCharacter(h, a, d) {
//     name = n;
// }
// void Player::addItem(string i) {
//     inventory.push_back(i);
// }
// int main() 
// {
//     GameCharacter gc = GameCharacter(100, 20, 10);
//     Player p = Player("Nimish", 100, 50, 20);
// }